package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Library;

public interface LibraryRepository extends JpaRepository<Library, Integer> {

	List<Library> findByNameContaining(String name);

	List<Library> findByLocationContaining(String location);

	List<Library> findByCapacity(Integer capacity);

	List<Library> findByNameContainingAndLocationContainingAndCapacity(String name, String location, Integer capacity);

	List<Library> findByNameContainingAndLocationContaining(String name, String location);

}
