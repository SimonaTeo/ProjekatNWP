package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Library;
import com.example.demo.repository.LibraryRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/libraries")
public class LibraryControler {

	@Autowired
	private LibraryRepository libraryRepo;

	@GetMapping("/all")
	public List<Library> getAllLibraries() {
		return libraryRepo.findAll();
	}

	@PostMapping("/create")
	public Library createLibrary(@RequestBody Library library) {
		return libraryRepo.save(library);
	}

	@GetMapping("/library/{id}")
	public ResponseEntity<Library> getLibraryById(@PathVariable Integer id) {
		Library library = libraryRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Library not exist with id :" + id));
		return ResponseEntity.ok(library);
	}
	
	@GetMapping("/search")
    public List<Library> searchLibraries(@RequestParam(required = false) String name,
                                         @RequestParam(required = false) String location,
                                         @RequestParam(required = false) Integer capacity) {
        
        if (name != null && location != null && capacity != null) {
            return libraryRepo.findByNameContainingAndLocationContainingAndCapacity(name, location, capacity);
        } else if (name != null && location != null) {
            return libraryRepo.findByNameContainingAndLocationContaining(name, location);
        } else if (name != null) {
            return libraryRepo.findByNameContaining(name);
        } else if (location != null) {
            return libraryRepo.findByLocationContaining(location);
        } else if (capacity != null) {
            return libraryRepo.findByCapacity(capacity);
        } else {
            return libraryRepo.findAll();
        }
    }
}
