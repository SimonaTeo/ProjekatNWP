package com.example.demo.controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Loan;
import com.example.demo.repository.LoanRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/loans")
public class LoanControler {

	@Autowired
	private LoanRepository loanRepo;

	@GetMapping()
	public List<Loan> getAllLoans() {
		return loanRepo.findAll();
	}

	@PostMapping()
	public Loan createLoan(@RequestBody Loan loan) {
		return loanRepo.save(loan);
	}

	@GetMapping("/loan/{id}")
	public ResponseEntity<Loan> getLoanById(@PathVariable Integer id) {
		Loan loan = loanRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Loan not exist with id :" + id));
		return ResponseEntity.ok(loan);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<Loan> updateLoan(@PathVariable Integer id, @RequestBody Loan loanDetails) {
		Loan loan = loanRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Loan not exist with id :" + id));

		loan.setBook(loanDetails.getBook());
		loan.setBorrowerName(loanDetails.getBorrowerName());
		loan.setLibrary(loanDetails.getLibrary());
		loan.setLoanDate(loanDetails.getLoanDate());
		loan.setReturnDate(loanDetails.getReturnDate());

		Loan updatedLoan = loanRepo.save(loan);
		return ResponseEntity.ok(updatedLoan);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteLoan(@PathVariable Integer id) {
		Loan loan = loanRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Loan not exist with id :" + id));

		loanRepo.delete(loan);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("/history/{bookId}")
    public ResponseEntity<List<Loan>> getLoanHistoryForBook(@PathVariable Integer bookId) {
        List<Loan> loanHistory = loanRepo.findByBookId(bookId);
        return ResponseEntity.ok(loanHistory);
    }
	
	@GetMapping("/check-loan-dates")
    public String checkLoanDates(@RequestParam String loanDate, @RequestParam String returnDate) {
        LocalDate loan = LocalDate.parse(loanDate);
        LocalDate returnD = LocalDate.parse(returnDate);
        
        long daysBetween = ChronoUnit.DAYS.between(loan, returnD);

        if (daysBetween > 30) {
            return "CROSSED THE RETURN DEADLINE, NEEDS TO PAY A FINE!";
        } else {
            return "Everything is fine, there is no penalty.";
        }
    }

}
