package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Book;
import com.example.demo.model.Loan;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.LoanRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/books")
public class BookControler {

	@Autowired
	private BookRepository bookRepo;
	
	@Autowired
    private LoanRepository loanRepo;

	@GetMapping
	public List<Book> getAllBooks() {
		return bookRepo.findAll();
	}

	@PostMapping()
	public Book createBook(@RequestBody Book book) {
		return bookRepo.save(book);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable Integer id) {
		Book book = bookRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Book not exist with id :" + id));
		return ResponseEntity.ok(book);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Book> updateBook(@PathVariable Integer id, @RequestBody Book bookDetails) {
		Book book = bookRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Book not exist with id :" + id));

		book.setTitle(bookDetails.getTitle());
		book.setAuthor(bookDetails.getAuthor());
		book.setGenre(bookDetails.getGenre());
		book.setPublishedYear(bookDetails.getPublishedYear());
		book.setLoans(bookDetails.getLoans());

		Book updatedBook = bookRepo.save(book);
		return ResponseEntity.ok(updatedBook);
	}
	
	@DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteBook(@PathVariable Integer id) {
        Book book = bookRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not exist with id :" + id));

        
        List<Loan> loans = loanRepo.findByBookId(id);
        loanRepo.deleteAll(loans);

        bookRepo.delete(book);

        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }
	
	 @GetMapping("/most-popular")
	    public List<Book> getMostPopularBooks(@RequestParam(defaultValue = "10") int limit) {
	        List<Book> popularBooks = bookRepo.findMostPopularBooks(limit);
	        return popularBooks;
	    }

	



}
