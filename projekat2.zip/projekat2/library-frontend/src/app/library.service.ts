import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Library } from './library';

@Injectable({
  providedIn: 'root'
})
export class LibraryService {

  private baseURL = "http://localhost:8080/libraries";

  constructor(private httpClient: HttpClient) { }

  getLibrariesList(): Observable<Library[]> {
    return this.httpClient.get<Library[]>(`${this.baseURL}/all`);
  }

  searchLibraries(name: string, location: string, capacity: number): Observable<Library[]> {
    let params = {};
    if (name) {
      params['name'] = name;
    }
    if (location) {
      params['location'] = location;
    }
    if (capacity) {
      params['capacity'] = capacity;
    }
    return this.httpClient.get<Library[]>(`${this.baseURL}/search`, { params: params });
  }
}
