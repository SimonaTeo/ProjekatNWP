import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookListComponent } from './book-list/book-list.component';
import { LibraryListComponent } from './library-list/library-list.component';
import { LoanListComponent } from './loan-list/loan-list.component';
import { HttpClientModule } from '@angular/common/http';
import { AddBookComponent } from './add-book/add-book.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdateBookComponent } from './update-book/update-book.component';
import { BookDetailsComponent } from './book-details/book-details.component';
import { AddLoanComponent } from './add-loan/add-loan.component';
import { SeeLoanComponent } from './see-loan/see-loan.component';
import { PopularBooksComponent } from './popular-books/popular-books.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';


@NgModule({
  declarations: [
    AppComponent,
    BookListComponent,
    LibraryListComponent,
    LoanListComponent,
    AddBookComponent,
    UpdateBookComponent,
    BookDetailsComponent,
    AddLoanComponent,
    SeeLoanComponent,
    PopularBooksComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
