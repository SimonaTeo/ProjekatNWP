import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookListComponent } from './book-list/book-list.component';
import { AddBookComponent } from './add-book/add-book.component';
import { UpdateBookComponent } from './update-book/update-book.component';
import { BookDetailsComponent } from './book-details/book-details.component';
import { LibraryListComponent } from './library-list/library-list.component';
import { LoanListComponent } from './loan-list/loan-list.component';
import { AddLoanComponent } from './add-loan/add-loan.component';
import { SeeLoanComponent } from './see-loan/see-loan.component';
import { PopularBooksComponent } from './popular-books/popular-books.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  {path: 'books', component:BookListComponent},
  {path: 'add-book', component:AddBookComponent},
  {path: 'update-book/:id', component:UpdateBookComponent},
  {path: 'book-details/:id', component:BookDetailsComponent},
  {path: 'libraries', component: LibraryListComponent },
  {path: 'loans', component:LoanListComponent},
  {path: 'add-loan/:id', component: AddLoanComponent},
  {path: 'see-loan/:id', component: SeeLoanComponent},
  {path: 'popular-books', component: PopularBooksComponent },
  {path: '', redirectTo: 'books', pathMatch: 'full'},
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
