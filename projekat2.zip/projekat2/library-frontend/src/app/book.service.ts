import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http'
import { Book } from './book';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private baseUrl="http://localhost:8080/books";

  constructor(private httpClient: HttpClient) { }

  getBooksList(): Observable<Book[]> {
    return this.httpClient.get<Book[]>(`${this.baseUrl}`);
  }

  addBook(book: Book): Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`, book);
  }

  getBookById(id: number): Observable<Book> {
    return this.httpClient.get<Book>(`${this.baseUrl}/${id}`);
  }

  updateBook(id: number, book: Book): Observable<Object>{
    return this.httpClient.put(`${this.baseUrl}/${id}`, book);
  }

  deleteBook(id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseUrl}/${id}`);
  }

  getMostPopularBooks(limit: number): Observable<Book[]> {
    return this.httpClient.get<Book[]>(`${this.baseUrl}/most-popular?limit=${limit}`);
  }


}
