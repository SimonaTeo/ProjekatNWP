import { Component, OnInit } from '@angular/core';
import { Library } from '../library';
import { LibraryService } from '../library.service';

@Component({
  selector: 'app-library-list',
  templateUrl: './library-list.component.html',
  styleUrls: ['./library-list.component.css']
})
export class LibraryListComponent implements OnInit {

  libraries:Library[];
  searchName: string;
  searchLocation: string;
  searchCapacity: number;

  constructor(private libraryService: LibraryService) { }

  ngOnInit(): void {
    this.getLibraries();
  }

  private getLibraries() {
    this.libraryService.getLibrariesList().subscribe(data => {
      this.libraries = data;
    });
  }

  searchLibraries() {
    this.libraryService.searchLibraries(this.searchName, this.searchLocation, this.searchCapacity)
      .subscribe(data => {
        this.libraries = data;
      });
  }

}
