import { Component, OnInit } from '@angular/core';
import { Loan } from '../loan';
import { Book } from '../book';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book.service';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-add-loan',
  templateUrl: './add-loan.component.html',
  styleUrls: ['./add-loan.component.css']
})
export class AddLoanComponent implements OnInit {

  loan: Loan = { id: 0, borrowerName: '', book: {} as Book, loanDate: new Date(),returnDate:new Date()};
  id: number;
  book: Book = new Book();

  constructor( private route: ActivatedRoute,
    private loanService: LoanService,
    private router: Router,
    private bookService: BookService
  ) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
   this.bookService.getBookById(this.id).subscribe(data => {
    this.book = data;
    this.loan.book = this.book;
  })}


  onSubmit() {
    this.loanService.addLoan(this.loan).subscribe( data => {
     this.goToLoanList();
    })
   }

   goToLoanList() {
    this.router.navigate(['/loans']);
  }


  

}
