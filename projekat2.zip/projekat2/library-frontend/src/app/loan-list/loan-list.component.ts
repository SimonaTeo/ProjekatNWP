import { Component, OnInit } from '@angular/core';
import { Loan } from '../loan';
import{LoanService} from '../loan.service';

@Component({
  selector: 'app-loan-list',
  templateUrl: './loan-list.component.html',
  styleUrls: ['./loan-list.component.css']
})
export class LoanListComponent implements OnInit {

  loans: Loan[];

  constructor(private loanService:LoanService) { }

  ngOnInit(): void {
    this.getLoans();
  }

  getLoans(): void {
    this.loanService.getLoansList().subscribe(
      loans => { 
        this.loans = loans;
      });
  }

  deleteLoan(id: number) {
    this.loanService.deleteLoan(id).subscribe( data => {
      this.getLoans();
    })
  }

}
