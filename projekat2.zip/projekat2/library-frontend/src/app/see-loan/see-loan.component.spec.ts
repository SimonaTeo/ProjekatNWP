import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeeLoanComponent } from './see-loan.component';

describe('SeeLoanComponent', () => {
  let component: SeeLoanComponent;
  let fixture: ComponentFixture<SeeLoanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeeLoanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeeLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
