import { Component, OnInit } from '@angular/core';
import { Loan } from '../loan';
import { ActivatedRoute } from '@angular/router';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-see-loan',
  templateUrl: './see-loan.component.html',
  styleUrls: ['./see-loan.component.css']
})
export class SeeLoanComponent implements OnInit {

  bookId: number;
  loanHistory: Loan[];

  loanDate: string;
  returnDate: string;
  message: string;

  constructor(private route: ActivatedRoute, private loanService: LoanService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.bookId = +params.get('id');
      this.getLoanHistory();
    });
  }

  getLoanHistory(): void {
    this.loanService.getLoanHistoryForBook(this.bookId)
      .subscribe(loanHistory => this.loanHistory = loanHistory);
  }

  checkDates(): void {
    if (this.loanDate && this.returnDate) {
      this.loanService.checkLoanDates(this.loanDate, this.returnDate)
        .subscribe(response => {
          this.message = response;
        });
    }
  }

}
