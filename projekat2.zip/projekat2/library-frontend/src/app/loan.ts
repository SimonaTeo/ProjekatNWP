import { Book } from "./book";
import { Library } from "./library";

export class Loan {
    id:number;
    borrowerName:string;
    loanDate:Date;
    returnDate:Date;
    book:Book;
    //library:Library;
}
