import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-popular-books',
  templateUrl: './popular-books.component.html',
  styleUrls: ['./popular-books.component.css']
})
export class PopularBooksComponent implements OnInit {

  popularBooks: Book[];
  
  constructor(private bookService: BookService) { }

  ngOnInit(): void {
    this.loadMostPopularBooks();
  }

  loadMostPopularBooks(): void {
    this.bookService.getMostPopularBooks(10).subscribe(
      data => {
        this.popularBooks = data;
      },
      error => {
        console.log(error);
      }
    );
  }

}
