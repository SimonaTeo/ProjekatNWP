import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookService } from '../book.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {

  bookForm: FormGroup;

  constructor(private fb: FormBuilder, private bookService: BookService, private router: Router) { }

  ngOnInit(): void {
    this.bookForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(3)]],
      author: ['', [Validators.required, Validators.minLength(3)]],
      genre: ['', Validators.required],
      publishedYear: ['', Validators.required]
    });
  }

  saveBook() {
    this.bookService.addBook(this.bookForm.value).subscribe(data => {
      console.log(data);
      this.goToBookList();
    },
    error => console.log(error));
  }

  goToBookList() {
    this.router.navigate(['/books']);
  }

  onSubmit() {
    if (this.bookForm.valid) {
      console.log(this.bookForm.value);
      this.saveBook();
    } else {
      console.log('Form is invalid');
    }
  }
}
