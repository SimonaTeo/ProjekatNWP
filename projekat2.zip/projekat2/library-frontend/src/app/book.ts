import { Loan } from "./loan";

export class Book {
    id:number;
    title:string;
    author:string;
    genre:string;
    publishedYear:number;
    loans: Loan[];

    
}
