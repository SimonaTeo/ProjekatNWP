import { Injectable } from '@angular/core';
import{HttpClient, HttpParams} from '@angular/common/http'
import { Loan } from './loan';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoanService {

  private baseUrl = 'http://localhost:8080/loans';

  constructor(private httpClient: HttpClient) { }

  getLoansList(): Observable<Loan[]> {
    return this.httpClient.get<Loan[]>(`${this.baseUrl}`);
  }

  addLoan(loan: Loan): Observable<Loan> {
    return this.httpClient.post<Loan>(this.baseUrl, loan);
  }

  deleteLoan(id: number): Observable<void> {
    return this.httpClient.delete<void>(`${this.baseUrl}/${id}`);
  }

  getLoanHistoryForBook(bookId: number): Observable<Loan[]> {
    return this.httpClient.get<Loan[]>(`${this.baseUrl}/history/${bookId}`);
  }

  checkLoanDates(loanDate: string, returnDate: string): Observable<string> {
    let params = new HttpParams();
    params = params.append('loanDate', loanDate);
    params = params.append('returnDate', returnDate);

    return this.httpClient.get(`${this.baseUrl}/check-loan-dates`, { params, responseType: 'text' });
  }

}
