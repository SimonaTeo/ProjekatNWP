import { Loan } from "./loan";

export class Library {

    id:number;
    capacity:number;
    location:string;
    name:string

}
