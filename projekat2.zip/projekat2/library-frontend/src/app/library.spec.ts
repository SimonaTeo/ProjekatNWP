import { Library } from './library';

describe('Library', () => {
  it('should create an instance', () => {
    expect(new Library()).toBeTruthy();
  });
});
